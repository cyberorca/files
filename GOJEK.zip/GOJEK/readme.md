Headline Grow
Template : KLY - Mobile Headline Grow - v3.0
LP : https://m.kapanlagi.com/

Bottom Frame Expand
Template : KLY Mobile Expand Bottomframe v0.1 - Fixed Size
LP : https://m.kapanlagi.com/

Mobile Puller
Template : KLY - Mobile Puller ( image ) - v3.1
LP : https://m.kapanlagi.com/

Spin Ads 3D
Template : KLY - mobile 3D Spinner - v1.0
LP : 
	1. https://m.kapanlagi.com/
	2. https://m.merdeka.com/
	3. https://m.bola.com/
	4. https://m.dream.co.id/
	5. https://m.otosia.com/
	6. https://m.kapanlagi.com/
	

Mobile Puller Flip
Template : KLY - Mobile Puller ( image ) - v2.0 - Flip
LP :
    1. https://www.newshub.id/interactive2/tetap-seru-selama-pandemi-dengan-series-the-world-of-the-married-tonton-di-sini-2095.html?skipintro=1
    2. https://www.newshub.id/interactive2/tetap-seru-selama-pandemi-dengan-series-penthouse-tonton-di-sini-2096.html?skipintro=1
    3. https://www.newshub.id/interactive2/tetap-seru-selama-pandemi-dengan-series-flower-of-evil-tonton-di-sini-2097.html?skipintro=1
    4. https://www.newshub.id/interactive2/tetap-seru-selama-pandemi-dengan-series-scandal-tonton-di-sini-2098.html?skipintro=1
    5. https://www.newshub.id/interactive2/tetap-seru-selama-pandemi-dengan-series-turn-on-tonton-di-sini-2099.html?skipintro=1